package dev.xkmc.youkaishomecoming.init.registrate;

import com.tterrag.registrate.builders.ItemBuilder;
import com.tterrag.registrate.util.entry.BlockEntry;
import com.tterrag.registrate.util.entry.ItemEntry;
import com.tterrag.registrate.util.nullness.NonNullFunction;
import dev.xkmc.fruitsdelight.init.FruitsDelight;
import dev.xkmc.l2core.init.reg.registrate.L2Registrate;
import dev.xkmc.l2core.init.reg.simple.DCReg;
import dev.xkmc.l2core.init.reg.simple.DCVal;
import dev.xkmc.l2core.util.DCStack;
import dev.xkmc.youkaishomecoming.compat.food.FruitsDelightCompatDrink;
import dev.xkmc.youkaishomecoming.compat.food.FruitsDelightCompatFood;
import dev.xkmc.youkaishomecoming.content.block.deco.BasketBlock;
import dev.xkmc.youkaishomecoming.content.block.food.EmptySaucerBlock;
import dev.xkmc.youkaishomecoming.content.block.food.SurpriseChestBlock;
import dev.xkmc.youkaishomecoming.content.block.food.SurpriseFeastBlock;
import dev.xkmc.youkaishomecoming.content.item.curio.CamelliaItem;
import dev.xkmc.youkaishomecoming.content.item.fluid.BottleTexture;
import dev.xkmc.youkaishomecoming.content.item.fluid.BottledFluid;
import dev.xkmc.youkaishomecoming.content.item.fluid.SakeBottleItem;
import dev.xkmc.youkaishomecoming.content.item.fluid.SlipBottleItem;
import dev.xkmc.youkaishomecoming.content.pot.table.food.YHRolls;
import dev.xkmc.youkaishomecoming.content.pot.table.food.YHSushi;
import dev.xkmc.youkaishomecoming.init.YoukaisHomecoming;
import dev.xkmc.youkaishomecoming.init.food.*;
import dev.xkmc.youkaishomecoming.util.DCFluid;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.MobBucketItem;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.fml.ModList;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.registries.datamaps.builtin.Compostable;
import net.neoforged.neoforge.registries.datamaps.builtin.NeoForgeDataMaps;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

public class YHItems {

	private static final Set<String> SMALL_WORDS = Set.of("of", "the", "with", "in");

	public static String toEnglishName(String internalName) {
		return Arrays.stream(internalName.split("_"))
				.map(e -> SMALL_WORDS.contains(e) ? e : StringUtils.capitalize(e))
				.collect(Collectors.joining(" "));
	}

	public static final BlockEntry<Block> SOYBEAN_BAG, PODS_CRATE,
			REDBEAN_BAG, CUCUMBER_BAG,
			TEA_BAG, BLACK_TEA_BAG, GREEN_TEA_BAG, OOLONG_TEA_BAG, WHITE_TEA_BAG, DARK_TEA_BAG, YELLOW_TEA_BAG,
			RED_GRAPE_CRATE, BLACK_GRAPE_CRATE, WHITE_GRAPE_CRATE;

	public static final BottledFluid<SakeBottleItem> SOY_SAUCE_BOTTLE, MAYONNAISE, CREAM;
	public static final ItemEntry<Item> CLAY_SAUCER, MATCHA, ICE_CUBE;
	public static final ItemEntry<CamelliaItem> CAMELLIA;
	public static final ItemEntry<SlipBottleItem> SAKE_BOTTLE;
	public static final BlockEntry<SurpriseChestBlock> SURP_CHEST;
	public static final BlockEntry<SurpriseFeastBlock> SURP_FEAST;
	public static final CakeEntry TARTE_LUNE;
	public static final BlockEntry<EmptySaucerBlock> SAUCER;
	public static final ItemEntry<MobBucketItem> LAMPREY_BUCKET, TUNA_BUCKET, CRAB_BUCKET;

	public static final ItemEntry<Item> EMPTY_HAND_ICON;

	private static final DCReg DC = DCReg.of(YoukaisHomecoming.REG);
	public static final DCVal<ItemContainerContents> DC_ITEMS = DC.reg("items", ItemContainerContents.CODEC, ItemContainerContents.STREAM_CODEC, false);
	public static final DCVal<DCFluid> DC_FLUID = DC.reg("fluid", FluidStack.OPTIONAL_CODEC.xmap(DCFluid::new, DCFluid::stack), FluidStack.OPTIONAL_STREAM_CODEC.map(DCFluid::new, DCFluid::stack), true);
	public static final DCVal<Integer> DC_HEAT = DC.intVal("heat");

	static {
		InitializationMarker.expectAndAdvance(3);

		YoukaisHomecoming.REGISTRATE.defaultCreativeTab(YoukaisHomecoming.CROP.key());

		// plants
		{
			YHCrops.register();
			YHTea.register();
			CAMELLIA = YoukaisHomecoming.REGISTRATE.item("camellia", CamelliaItem::new).model(CamelliaItem::buildModel)
					.dataMap(NeoForgeDataMaps.COMPOSTABLES, new Compostable(0.8f)).register();
			MATCHA = crop("matcha", Item::new)
					.dataMap(NeoForgeDataMaps.COMPOSTABLES, new Compostable(0.8f)).register();
			CUCUMBER_BAG = YHCrops.CUCUMBER.createCrate();
			RED_GRAPE_CRATE = YHCrops.RED_GRAPE.createCrate();
			BLACK_GRAPE_CRATE = YHCrops.BLACK_GRAPE.createCrate();
			WHITE_GRAPE_CRATE = YHCrops.WHITE_GRAPE.createCrate();
			PODS_CRATE = YHCrops.createCrate("pod");
			SOYBEAN_BAG = YHCrops.SOYBEAN.createBag();
			REDBEAN_BAG = YHCrops.REDBEAN.createBag();
			TEA_BAG = YHCrops.createBag("tea_leaf");
			BLACK_TEA_BAG = YHTea.BLACK.createBags();
			GREEN_TEA_BAG = YHTea.GREEN.createBags();
			OOLONG_TEA_BAG = YHTea.OOLONG.createBags();
			WHITE_TEA_BAG = YHTea.WHITE.createBags();
			DARK_TEA_BAG = YHTea.DARK.createBags();
			YELLOW_TEA_BAG = YHTea.YELLOW.createBags();

			BasketBlock.register();
		}

		YoukaisHomecoming.REGISTRATE.defaultCreativeTab(YoukaisHomecoming.FOOD.key());

		// ingredients
		{
			SOY_SAUCE_BOTTLE = new BottledFluid<>("soy_sauce", "soy_sauce_bottle", () -> Items.GLASS_BOTTLE, "ingredient", SakeBottleItem::new).bottle();
			MAYONNAISE = new BottledFluid<>("mayonnaise", "mayonnaise_bottle", () -> Items.GLASS_BOTTLE, "ingredient", SakeBottleItem::new).bottle();
			CREAM = new BottledFluid<>("cream", "bowl_of_cream", () -> Items.BOWL, "ingredient", SakeBottleItem::new);

			ICE_CUBE = ingredient("ice_cube", Item::new);
		}

		{

			CLAY_SAUCER = YoukaisHomecoming.REGISTRATE.item("clay_saucer", Item::new).register();

			SAUCER = YoukaisHomecoming.REGISTRATE.block("saucer", EmptySaucerBlock::new)
					.initialProperties(() -> Blocks.LIGHT_GRAY_WOOL)
					.blockstate((ctx, pvd) -> pvd.horizontalBlock(ctx.get(),
							state -> state.getValue(EmptySaucerBlock.TYPE).build(pvd)))
					.item().model((ctx, pvd) -> pvd.generated(ctx)).build()
					.register();


			SAKE_BOTTLE = YoukaisHomecoming.REGISTRATE.item("sake_bottle", SlipBottleItem::new)
					.properties(p -> p.stacksTo(1))
					.model(BottleTexture::buildBottleModel)
					.color(() -> () -> SlipBottleItem::color)
					.lang("Flask")
					.register();
		}


		InitializationMarker.expectAndAdvance(4);
		YHFood.register();
		YHSushi.register();
		YHRolls.init();
		YHBowl.register();
		YHDish.register();
		YHPotFood.register();

		YHDrink.register();

		if (ModList.get().isLoaded(FruitsDelight.MODID)) {
			FruitsDelightCompatFood.register();
			FruitsDelightCompatDrink.register();
		}

		// feasts
		{
			SURP_CHEST = YoukaisHomecoming.REGISTRATE.block("chest_of_heart_throbbing_surprise", SurpriseChestBlock::new)
					.initialProperties(() -> Blocks.BROWN_WOOL)
					.item().properties(p -> p.stacksTo(1)).model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/feast/" + ctx.getName()))).build()
					.blockstate(SurpriseChestBlock::buildModel)
					.register();

			SURP_FEAST = YoukaisHomecoming.REGISTRATE.block("heart_throbbing_surprise", p ->
							new SurpriseFeastBlock(p, YHFood.BOWL_OF_HEART_THROBBING_SURPRISE.item))
					.initialProperties(() -> Blocks.BROWN_WOOL)
					.blockstate(SurpriseFeastBlock::buildModel)
					.loot(SurpriseFeastBlock::builtLoot)
					.register();

			TARTE_LUNE = new CakeEntry("tarte_lune", MapColor.COLOR_PURPLE, FoodType.SIMPLE, 4, 0.6f, false);
		}

		YoukaisHomecoming.REGISTRATE.defaultCreativeTab(YoukaisHomecoming.TAB.key());

		LAMPREY_BUCKET = YoukaisHomecoming.REGISTRATE
				.item("lamprey_bucket", p -> new MobBucketItem(
						YHEntities.LAMPREY.get(), Fluids.WATER, SoundEvents.BUCKET_EMPTY_FISH,
						p.stacksTo(1).craftRemainder(Items.BUCKET)))
				.defaultLang()
				.register();

		TUNA_BUCKET = YoukaisHomecoming.REGISTRATE
				.item("tuna_bucket", p -> new MobBucketItem(
						YHEntities.TUNA.get(), Fluids.WATER, SoundEvents.BUCKET_EMPTY_FISH,
						p.stacksTo(1).craftRemainder(Items.BUCKET)))
				.defaultLang()
				.register();

		CRAB_BUCKET = YoukaisHomecoming.REGISTRATE
				.item("crab_bucket", p -> new MobBucketItem(
						YHEntities.CRAB.get(), Fluids.WATER, SoundEvents.BUCKET_EMPTY_FISH,
						p.stacksTo(1).craftRemainder(Items.BUCKET)))
				.defaultLang()
				.register();

		EMPTY_HAND_ICON = YoukaisHomecoming.REGISTRATE.item("empty_hand_icon", Item::new)
				.removeTab(YoukaisHomecoming.TAB.key()).register();

		InitializationMarker.expectAndAdvance(6);

	}

	public static <T extends Item> ItemBuilder<T, ?> seed(String id, NonNullFunction<Item.Properties, T> factory) {
		return YoukaisHomecoming.REGISTRATE.item(id, factory)
				.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/crops/" + ctx.getName())));
	}

	public static <T extends Item> ItemBuilder<T, L2Registrate> crop(String id, NonNullFunction<Item.Properties, T> factory) {
		return YoukaisHomecoming.REGISTRATE.item(id, factory)
				.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/crops/" + ctx.getName())));
	}

	public static <T extends Item> ItemEntry<T> ingredient(String id, NonNullFunction<Item.Properties, T> factory) {
		return YoukaisHomecoming.REGISTRATE.item(id, factory)
				.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/ingredient/" + ctx.getName())))
				.register();
	}

	public static void register() {
	}

}
