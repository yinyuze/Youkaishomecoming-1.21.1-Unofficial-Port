package dev.xkmc.youkaishomecoming.init.data;

import com.tterrag.registrate.providers.RegistrateItemTagsProvider;
import com.tterrag.registrate.providers.RegistrateTagsProvider;
import dev.xkmc.youkaishomecoming.compat.sereneseasons.SeasonCompat;
import dev.xkmc.youkaishomecoming.init.YoukaisHomecoming;
import dev.xkmc.youkaishomecoming.init.food.YHCrops;
import dev.xkmc.youkaishomecoming.init.food.YHTea;
import dev.xkmc.youkaishomecoming.init.registrate.YHItems;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.fml.ModList;
import sereneseasons.core.SereneSeasons;
import vectorwing.farmersdelight.common.registry.ModBlocks;
import vectorwing.farmersdelight.common.registry.ModItems;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class YHTagGen {

	public static final TagKey<Item> RAW_EEL = c("foods/raw_eel");
	public static final TagKey<Item> COOKED_EEL = c("foods/cooked_eel");
	public static final TagKey<Item> RAW_TUNA = c("foods/raw_tuna");
	public static final TagKey<Item> COOKED_TUNA = c("foods/cooked_tuna");
	public static final TagKey<Item> RAW_VENISON = c("foods/raw_venison");
	public static final TagKey<Item> COOKED_VENISON = c("foods/cooked_venison");
	public static final TagKey<Item> RAW_BOAR = c("foods/raw_boar");
	public static final TagKey<Item> COOKED_BOAR = c("foods/cooked_boar");
	public static final TagKey<Item> RAW_CRAB = c("foods/raw_crab");
	public static final TagKey<Item> COOKED_CRAB = c("foods/cooked_crab");
	public static final TagKey<Item> BUTTER = c("foods/butter");
	public static final TagKey<Item> CUCUMBER = c("crops/cucumber");
	public static final TagKey<Item> CUCUMBER_SLICE = c("foods/slices/cucumber");
	public static final TagKey<Item> CUCUMBER_SEED = c("seeds/cucumber");
	public static final TagKey<Item> VEGE = c("foods/vegetable");
	public static final TagKey<Item> GRAPE = c("foods/fruits/grape");
	public static final TagKey<Item> FRUIT = c("foods/fruits");
	public static final TagKey<Item> SEED = c("seeds");
	public static final TagKey<Item> SOY_SAUCE_BOTTLE = c("bottles/soy_sauce");
	public static final TagKey<Item> MAYONNAISE_BOTTLE = c("bottles/mayonnaise");
	public static final TagKey<Item> SALMON_ROE = c("foods/roes/salmon");
	public static final TagKey<Item> CRAB_ROE = c("foods/roes/crab");
	public static final TagKey<Item> NATTOU = c("foods/nattou");
	public static final TagKey<Item> OTORO = c("foods/otoro");
	public static final TagKey<Item> SOYBEAN = c("crops/soybean");
	public static final TagKey<Item> REDBEAN = c("crops/redbean");
	public static final TagKey<Item> IMITATION_CRAB = c("foods/imitation_crab");
	public static final TagKey<Item> TAMAGOYAKI_SLICE = c("foods/slices/tamagoyaki");
	public static final TagKey<Item> GRAPE_SEED = item("grape_seed");
	public static final TagKey<Item> TAMAGOYAKI = item("tamagoyaki");
	public static final TagKey<Item> COOKED_RICE = item("cuisine/cooked_rice");
	public static final TagKey<Item> DRIED_KELP = item("cuisine/dried_kelp");
	public static final TagKey<Item> BAMBOO = item("cuisine/bamboo");
	public static final TagKey<Item> CARROT = item("cuisine/carrot");
	public static final TagKey<Item> BROWN_MUSHROOM = item("cuisine/brown_mushroom");
	public static final TagKey<Item> DANGO = item("dango");
	public static final TagKey<Item> TEA_DRINK = item("tea");
	public static final TagKey<Item> SAKE = item("sake");
	public static final TagKey<Item> WINE = item("wine");
	public static final TagKey<Item> BOTTLED = item("bottled");
	public static final TagKey<Item> STEAM_BLOCKER = item("steam_blocker");
	public static final TagKey<Item> PLACE_WITH_CONTAINER = item("place_with_container");
	public static final TagKey<Item> IRON_BOWL_FOOD = item("iron_bowl_food");
	public static final TagKey<Block> FARMLAND_SOYBEAN = block("farmland_soybean");
	public static final TagKey<Block> FARMLAND_REDBEAN = block("farmland_redbean");
	public static final TagKey<Block> FARMLAND_TEA = block("farmland_tea");
	public static final TagKey<Block> CRAB_DIGABLE = block("crab_digable");


	public static final TagKey<Item> MATCHA = c("matcha");
	public static final TagKey<Item> ICE = c("ice_cubes");

	public static final TagKey<Item> TEA_GREEN = c("tea_leaves/green");
	public static final TagKey<Item> TEA_BLACK = c("tea_leaves/black");
	public static final TagKey<Item> TEA_WHITE = c("tea_leaves/white");
	public static final TagKey<Item> TEA_OOLONG = c("tea_leaves/oolong");
	public static final TagKey<Item> TEA_DARK = c("tea_leaves/dark");
	public static final TagKey<Item> TEA_YELLOW = c("tea_leaves/yellow");
	public static final TagKey<Item> TEA = c("tea_leaves");

	public static final List<Consumer<RegistrateItemTagsProvider>> OPTIONAL_TAGS = new ArrayList<>();

	public static void onEntityTagGen(RegistrateTagsProvider.IntrinsicImpl<EntityType<?>> pvd) {

	}

	public static void onBlockTagGen(RegistrateTagsProvider.IntrinsicImpl<Block> pvd) {
		pvd.addTag(FARMLAND_SOYBEAN).add(Blocks.FARMLAND, ModBlocks.RICH_SOIL_FARMLAND.get());
		pvd.addTag(FARMLAND_REDBEAN).add(Blocks.CLAY, Blocks.MUD, Blocks.COARSE_DIRT, ModBlocks.RICH_SOIL_FARMLAND.get());
		pvd.addTag(FARMLAND_TEA).add(Blocks.GRASS_BLOCK, ModBlocks.RICH_SOIL.get());
		pvd.addTag(CRAB_DIGABLE).add(Blocks.SAND, Blocks.GRAVEL);
		if (ModList.get().isLoaded(SereneSeasons.MOD_ID)) {
			SeasonCompat.genBlock(pvd);
		}
	}

	@SuppressWarnings("unchecked")
	public static void onItemTagGen(RegistrateItemTagsProvider pvd) {
		pvd.addTag(VEGE).addTag(CUCUMBER);
		pvd.addTag(CUCUMBER).add(YHCrops.CUCUMBER.getFruits());
		pvd.addTag(SEED).addTag(CUCUMBER_SEED);
		pvd.addTag(CUCUMBER_SEED).add(YHCrops.CUCUMBER.getSeed());
		pvd.addTag(GRAPE).add(YHCrops.RED_GRAPE.getFruits(), YHCrops.BLACK_GRAPE.getFruits(), YHCrops.WHITE_GRAPE.getFruits());
		pvd.addTag(FRUIT).addTag(GRAPE);
		pvd.addTag(GRAPE_SEED).add(YHCrops.RED_GRAPE.getSeed(), YHCrops.BLACK_GRAPE.getSeed(), YHCrops.WHITE_GRAPE.getSeed());
		pvd.addTag(SOY_SAUCE_BOTTLE).add(YHItems.SOY_SAUCE_BOTTLE.asItem());
		pvd.addTag(MAYONNAISE_BOTTLE).add(YHItems.MAYONNAISE.asItem());
		pvd.addTag(SOYBEAN).add(YHCrops.SOYBEAN.getSeed());
		pvd.addTag(REDBEAN).add(YHCrops.REDBEAN.getSeed());

		pvd.addTag(COOKED_RICE).add(ModItems.COOKED_RICE.get());
		pvd.addTag(DRIED_KELP).add(Items.DRIED_KELP);
		pvd.addTag(BAMBOO).add(Items.BAMBOO);
		pvd.addTag(CARROT).add(Items.CARROT);
		pvd.addTag(BROWN_MUSHROOM).add(Items.BROWN_MUSHROOM);

		pvd.addTag(MATCHA).add(YHItems.MATCHA.get())
				.addOptional(ResourceLocation.fromNamespaceAndPath("delightful", "matcha"));
		pvd.addTag(ICE).add(YHItems.ICE_CUBE.get());
		pvd.addTag(TEA_GREEN).add(YHTea.GREEN.leaves.get());
		pvd.addTag(TEA_BLACK).add(YHTea.BLACK.leaves.get());
		pvd.addTag(TEA_WHITE).add(YHTea.WHITE.leaves.get());
		pvd.addTag(TEA_OOLONG).add(YHTea.OOLONG.leaves.get());
		pvd.addTag(TEA_DARK).add(YHTea.DARK.leaves.get());
		pvd.addTag(TEA_YELLOW).add(YHTea.YELLOW.leaves.get());
		pvd.addTag(TEA).add(YHCrops.TEA.getFruits())
				.addTags(TEA_GREEN, TEA_BLACK, TEA_WHITE, TEA_OOLONG, TEA_DARK, TEA_YELLOW);

		pvd.addTag(c("butter")).addTag(BUTTER);

		if (ModList.get().isLoaded(SereneSeasons.MOD_ID)) {
			SeasonCompat.genItem(pvd);
		}
		for (var e : OPTIONAL_TAGS) {
			e.accept(pvd);
		}

	}

	public static TagKey<Item> item(String id) {
		return ItemTags.create(YoukaisHomecoming.loc(id));
	}

	public static TagKey<Item> c(String id) {
		return ItemTags.create(ResourceLocation.fromNamespaceAndPath("c", id));
	}

	public static TagKey<Block> block(String id) {
		return BlockTags.create(YoukaisHomecoming.loc(id));
	}

	public static TagKey<EntityType<?>> entity(String id) {
		return TagKey.create(Registries.ENTITY_TYPE, YoukaisHomecoming.loc(id));
	}

	public static TagKey<EntityType<?>> entity(String mod, String id) {
		return TagKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(mod, id));
	}

}
