package dev.xkmc.youkaishomecoming.init.data;

import com.google.common.collect.Streams;
import com.mojang.datafixers.util.Pair;
import com.tterrag.registrate.providers.RegistrateAdvancementProvider;
import dev.xkmc.l2core.serial.advancements.AdvancementGenerator;
import dev.xkmc.l2core.serial.advancements.CriterionBuilder;
import dev.xkmc.youkaishomecoming.content.pot.table.food.YHRolls;
import dev.xkmc.youkaishomecoming.content.pot.table.food.YHSushi;
import dev.xkmc.youkaishomecoming.init.YoukaisHomecoming;
import dev.xkmc.youkaishomecoming.init.food.*;
import dev.xkmc.youkaishomecoming.init.registrate.*;
import net.minecraft.Util;
import net.minecraft.advancements.AdvancementType;
import net.minecraft.advancements.critereon.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;

import java.util.Arrays;
import java.util.Optional;
import java.util.stream.Stream;

public class YHAdvGen {

	public static void genAdv(RegistrateAdvancementProvider pvd) {
		var gen = new AdvancementGenerator(pvd, YoukaisHomecoming.MODID);
		var b = gen.new TabBuilder("main");
		var root = b.root("welcome_to_gensokyo", YHItems.BLACK_TEA_BAG.asStack(),
				CriterionBuilder.one(PlayerTrigger.TriggerInstance.tick()),
				"Gensokyo Delight", "Welcome To Gensokyo");
		var dango = root.create("sweet", YHFood.MOCHI.item.asStack(),
				CriterionBuilder.one(ConsumeItemTrigger.TriggerInstance.usedItem(
						ItemPredicate.Builder.item().of(YHTagGen.DANGO))),
				"Sweet?", "Eat a Mochi");
		dango.create("breed_deer", YHFood.SAKURA_MOCHI.asItem(),
				CriterionBuilder.one(BredAnimalsTrigger.TriggerInstance.bredAnimals(
						EntityPredicate.Builder.entity().of(YHEntities.DEER.get()))),
				"Oh Deer", "Breed deer with sakura mochi");
		dango.create("hmm", YHFood.SWEET_ORMOSIA_MOCHI_MIXED_BOILED.item.asStack(),
				CriterionBuilder.item(YHFood.SWEET_ORMOSIA_MOCHI_MIXED_BOILED.item.get()),
				"Hmm... Is it right?", "Get a Sweet Ormosia Mochi Mixed Boiled");
		root.create("soybean", YHCrops.SOYBEAN.getSeed(),
				CriterionBuilder.one(ItemUsedOnLocationTrigger.TriggerInstance.itemUsedOnBlock(
						LocationPredicate.Builder.location().setBlock(
								BlockPredicate.Builder.block().of(YHTagGen.FARMLAND_SOYBEAN)),
						ItemPredicate.Builder.item().of(YHCrops.SOYBEAN.getSeed()))),
				"The Essential Harvest", "Plant Soybean");
		root.create("cucumber", YHCrops.CUCUMBER.getSeed(),
						CriterionBuilder.one(ItemUsedOnLocationTrigger.TriggerInstance.itemUsedOnBlock(
								LocationPredicate.Builder.location().setBlock(
										BlockPredicate.Builder.block().of(YHTagGen.FARMLAND_SOYBEAN)),
								ItemPredicate.Builder.item().of(YHCrops.CUCUMBER.getSeed()))),
						"Rope Climber", "Plant Cucumber")
				.create("cucumber_top", YHCrops.CUCUMBER.getFruits(),
						CriterionBuilder.one(YHCriteriaTriggers.CUCUMBER.get().createCriterion(new PlayerTrigger.TriggerInstance(Optional.empty()))),
						"Pinnacle Kappa", "Let cucumber climb ropes and harvest the top cucumber of a 3-block tall cucumber crop");
		var grape = root.create("grape", YHCrops.RED_GRAPE.getSeed(),
				CriterionBuilder.one(ItemUsedOnLocationTrigger.TriggerInstance.itemUsedOnBlock(
						LocationPredicate.Builder.location().setBlock(
								BlockPredicate.Builder.block().of(YHTagGen.FARMLAND_SOYBEAN)),
						ItemPredicate.Builder.item().of(YHTagGen.GRAPE_SEED))),
				"Sweet Vines", "Plant Grape");
		grape.create("grape_cut", Items.SHEARS,
						CriterionBuilder.one(YHCriteriaTriggers.GRAPE_CUT.get().createCriterion(new PlayerTrigger.TriggerInstance(Optional.empty()))),
						"Niwaki", "Cut the leaves off a mature grape crop so that it can grow larger. Make sure it has 3 ropes in a row to climb onto.")
				.create("grape_harvest", YHCrops.RED_GRAPE.getFruits(),
						CriterionBuilder.one(YHCriteriaTriggers.GRAPE_HARVEST.get().createCriterion(new PlayerTrigger.TriggerInstance(Optional.empty()))),
						"The Best Bunch", "Harvest grape hanging under a grape branch");
		grape.create("squeeze", YHBlocks.BASIN.asItem(),
				CriterionBuilder.one(YHCriteriaTriggers.BASIN.get().createCriterion(new PlayerTrigger.TriggerInstance(Optional.empty()))),
				"Squeeze!", "Jump in the basin to squeeze juice out of grapes");

		root.create("redbean", YHCrops.REDBEAN.getSeed(),
				CriterionBuilder.one(ItemUsedOnLocationTrigger.TriggerInstance.itemUsedOnBlock(
						LocationPredicate.Builder.location().setBlock(
								BlockPredicate.Builder.block().of(YHTagGen.FARMLAND_REDBEAN)),
						ItemPredicate.Builder.item().of(YHCrops.REDBEAN.getSeed()))),
				"Leanness Resistant Red Bean", "Plant Red Bean on Coarse Dirt, Mud, or Clay");
		var tea = root.create("tea", YHCrops.TEA.getSeed(),
				CriterionBuilder.one(ItemUsedOnLocationTrigger.TriggerInstance.itemUsedOnBlock(
						LocationPredicate.Builder.location().setBlock(
								BlockPredicate.Builder.block().of(YHTagGen.FARMLAND_TEA)),
						ItemPredicate.Builder.item().of(YHCrops.TEA.getSeed()))),
				"Refreshing Hobby", "Plant Tea on grass block.");
		tea.create("camellia", YHItems.CAMELLIA.asItem(), CriterionBuilder.item(YHItems.CAMELLIA.asItem()),
				"Scent of Camellia", "Collect Camellia from tea crop");
		tea.create("tea_leaves", YHCrops.TEA.getFruits(), CriterionBuilder.item(YHCrops.TEA.getFruits()),
						"Mellow Fragrance", "Collect tea leaves before tea crop starts flowering")
				.create("tea_master", YHDrink.OOLONG_TEA.item.asStack(),
						Util.make(CriterionBuilder.and(), c -> Stream.of(
										YHDrink.WHITE_TEA, YHDrink.OOLONG_TEA, YHDrink.GREEN_TEA, YHDrink.DARK_TEA, YHDrink.BLACK_TEA, YHDrink.YELLOW_TEA
								).map(e -> e.item.get()).map(e -> Pair.of(e, ConsumeItemTrigger.TriggerInstance.usedItem(e)))
								.forEach(p -> c.add(BuiltInRegistries.ITEM.getKey(p.getFirst().asItem()).toString(), p.getSecond()))),
						"Tea Master", "Drink all kinds of tea in original flavor")
				.type(AdvancementType.GOAL, true, true, false);
		root.create("udumbara", YHCrops.UDUMBARA.getWildPlant().asItem(),
						CriterionBuilder.one(ItemUsedOnLocationTrigger.TriggerInstance.itemUsedOnBlock(
								LocationPredicate.Builder.location().setBlock(
										BlockPredicate.Builder.block().of(Blocks.FARMLAND)),
								ItemPredicate.Builder.item().of(YHCrops.UDUMBARA.getSeed()))),
						"Moon Crop", "Plants an Udumbara with its leaves. It grows under moonlight and shrinks under sunlight.")
				.create("udumbara_leaves", YHCrops.UDUMBARA.getSeed(),
						CriterionBuilder.one(YHCriteriaTriggers.UDUMBARA_LEAVES.get().createCriterion(new PlayerTrigger.TriggerInstance(Optional.empty()))),
						"Transplant", "Harvest Udumbara Leaves from Udumbaar crop near maturity")
				.create("udumbara_flower", YHCrops.UDUMBARA.getFruits(),
						CriterionBuilder.item(YHCrops.UDUMBARA.getFruits()),
						"Fragile Flower", "Get an Udubara flower. It will only appear for 10 seconds during full moon.")
				.type(AdvancementType.CHALLENGE);
		root.create("alcoholic", YHBlocks.FERMENT.asStack(),
						CriterionBuilder.one(EffectsChangedTrigger.TriggerInstance.hasEffects(
								MobEffectsPredicate.Builder.effects().and(YHEffects.DRUNK))),
						"Alcoholic", "Brew and drink an alcoholic drink and obtain Drunk effect")
				.create("passed_out", YHDrink.DASSAI.item.asStack(),
						CriterionBuilder.one(EffectsChangedTrigger.TriggerInstance.hasEffects(
								MobEffectsPredicate.Builder.effects().and(YHEffects.DRUNK,
										new MobEffectsPredicate.MobEffectInstancePredicate(
												MinMaxBounds.Ints.atLeast(4), MinMaxBounds.Ints.ANY,
												Optional.empty(), Optional.empty())))),
						"Passed Out", "Drink until you have maximum Drunk effect");
		root.create("crab_grab", YHItems.CRAB_BUCKET.asItem(),
				CriterionBuilder.one(YHCriteriaTriggers.CRAB_GRAB.get().createCriterion(new PlayerTrigger.TriggerInstance(Optional.empty()))),
				"Crab Grab", "Have a crab grab your water bucket when attempting to bucket a crab");
		root.create("breed_boar", Items.CARROT,
				CriterionBuilder.one(BredAnimalsTrigger.TriggerInstance.bredAnimals(
						EntityPredicate.Builder.entity().of(YHEntities.BOAR.get()))),
				"Pig with Tusks", "Breed boar with carrot, potato, or beetroot");

		root.create("small_pot", YHBlocks.IRON_POT.asStack(),
						CriterionBuilder.one(YHCriteriaTriggers.COOKING.get().createCriterion(new PlayerTrigger.TriggerInstance(Optional.empty()))),
						"Hotpot", "Cooking with small iron pot / short pot / stockpot")
				.create("pot_grab", YHBowl.POWER_SOUP.asItem(),
						CriterionBuilder.one(YHCriteriaTriggers.POT_GRAB.get().createCriterion(new PlayerTrigger.TriggerInstance(Optional.empty()))),
						"Shared Enjoyment", "Use small iron pot to take a serve of food from short pot / stockpot");
		var steam = root.create("steamer", YHBlocks.STEAMER_POT.asStack(),
				CriterionBuilder.one(YHCriteriaTriggers.STEAM.get().steam(MinMaxBounds.Ints.ANY)),
				"Steam and Racks", "Steam some food");
		steam.create("dish", YHDish.IMITATION_BEAR_PAW.block.asStack(),
						CriterionBuilder.one(YHCriteriaTriggers.STEAM.get().steam(YHTagGen.STEAM_BLOCKER)),
						"Steam Interceptor", "Steam a plate meal or bamboo meal. Note that they heavily obstruct steam.")
				.type(AdvancementType.GOAL);
		steam.create("max_steamer", YHBlocks.STEAMER_RACK.asStack(),
						CriterionBuilder.one(YHCriteriaTriggers.STEAM.get().steam(MinMaxBounds.Ints.atLeast(18))),
						"Bamboo Tower", "Steam an item on the 18th rack")
				.type(AdvancementType.CHALLENGE);

		var table = root.create("cuisine_board", YHBlocks.CUISINE_BOARD.asStack(),
				CriterionBuilder.one(YHCriteriaTriggers.TABLE.get().createCriterion(new PlayerTrigger.TriggerInstance(Optional.empty()))),
				"Sushi Apprentice", "Make something with cuisine board");
		table.create("kaguya_hime", YHBowl.KAGUYA_HIME.item.asStack(),
						CriterionBuilder.item(YHBowl.KAGUYA_HIME.item.asItem()),
						"Tale of the Bamboo Princess", "Craft and Steam Kaguya Hime")
				.type(AdvancementType.GOAL);
		table.create("sushi_master", YHSushi.OTORO_NIGIRI.asItem(),
						CriterionBuilder.and()
								.add(InventoryChangeTrigger.TriggerInstance.hasItems(YHSushi.OTORO_NIGIRI.asItem()))
								.add(InventoryChangeTrigger.TriggerInstance.hasItems(YHSushi.TOBIKO_GUNKAN.asItem()))
								.add(InventoryChangeTrigger.TriggerInstance.hasItems(YHSushi.LORELEI_NIGIRI.asItem()))
								.add(InventoryChangeTrigger.TriggerInstance.hasItems(YHRolls.RAINBOW_FUTOMAKI.slice.asItem())),
						"Sushi Master", "Make Otoro Nigiri, Lorelei Nigiri, Tobiko Gunkan, and Rainbow Futomaki Slice")
				.type(AdvancementType.GOAL);
		table.create("foreign_sushi_master", YHRolls.RAINBOW_ROLL.slice.asItem(),
						CriterionBuilder.and()
								.add(InventoryChangeTrigger.TriggerInstance.hasItems(YHRolls.RAINBOW_ROLL.slice.asItem()))
								.add(InventoryChangeTrigger.TriggerInstance.hasItems(YHRolls.VOLCANO_ROLL.slice.asItem())),
						"Sushi Aboard", "Make Rainbow Roll Slice and Volcano Roll Slice")
				.type(AdvancementType.GOAL);
		root.create("enthusiastic", YHDish.IMITATION_BEAR_PAW.block.asStack(),
						Util.make(CriterionBuilder.and(), c -> Streams.concat(
										Arrays.stream(YHDish.values()).map(e -> e.block.get()),
										Arrays.stream(YHDrink.values()).map(e -> e.item.get()),
										Arrays.stream(YHBowl.values()).map(e -> e.item.get()),
										Arrays.stream(YHFood.values()).map(e -> e.item.get()),
										Arrays.stream(YHSushi.values()).map(e -> e.item.get()),
										Arrays.stream(YHRolls.values()).map(e -> e.slice.get()))
								.map(e -> Pair.of(e, ConsumeItemTrigger.TriggerInstance.usedItem(e)))
								.forEach(p -> c.add(BuiltInRegistries.ITEM.getKey(p.getFirst().asItem()).toString(), p.getSecond()))),
						"Gensokyo Food Enthusiastic", "Eat all Youkai's Homecoming food")
				.type(AdvancementType.CHALLENGE, true, true, false);

		root.finish();
	}

}
