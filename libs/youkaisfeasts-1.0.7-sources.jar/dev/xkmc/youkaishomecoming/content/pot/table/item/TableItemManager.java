package dev.xkmc.youkaishomecoming.content.pot.table.item;

import com.mojang.datafixers.util.Either;
import com.mojang.datafixers.util.Pair;
import dev.xkmc.youkaishomecoming.content.pot.table.food.FoodModelHelper;
import dev.xkmc.youkaishomecoming.content.pot.table.food.TableBambooBowls;
import dev.xkmc.youkaishomecoming.content.pot.table.model.*;
import dev.xkmc.youkaishomecoming.init.YoukaisHomecoming;
import dev.xkmc.youkaishomecoming.init.data.YHTagGen;
import dev.xkmc.youkaishomecoming.init.registrate.YHBlocks;
import dev.xkmc.youkaishomecoming.init.registrate.YHItems;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import vectorwing.farmersdelight.common.tag.CommonTags;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TableItemManager extends BaseTableItem {

	public static final ModelHolderManager MANAGER = ModelHolderManager.createModelBuilderManager(YoukaisHomecoming.REGISTRATE);

	private static FixedModelHolder fixed(String id) {
		return new FixedModelHolder(MANAGER, YoukaisHomecoming.loc("fixed/" + id));
	}

	private static VariantModelHolder variant(String id) {
		return new VariantModelHolder(MANAGER, YoukaisHomecoming.loc(id));
	}

	private static AdditionalModelHolder top(String id) {
		return new AdditionalModelHolder(MANAGER, YoukaisHomecoming.loc(id));
	}

	public static final TableItemManager TABLE = new TableItemManager();

	public static final IngredientTableItem RICE = TABLE.with(fixed("rice").putDefault("rice"), YHTagGen.COOKED_RICE);
	public static final IngredientTableItem SUSHI = RICE.addNext(variant("sushi").putDefault("rice"));
	public static final IngredientTableItem GUNKAN = SUSHI.with(variant("gunkan").putDefault("rice", "kelp"), YHTagGen.DRIED_KELP);
	public static final IngredientTableItem RICE_2 = RICE.with(fixed("rice_2").putDefault("rice"), YHTagGen.COOKED_RICE);
	public static final IngredientTableItem CAL = RICE_2.with(variant("open_california").putDefault("rice", "kelp"), YHTagGen.DRIED_KELP);

	public static final IngredientTableItem KELP = TABLE.with(fixed("kelp").putDefault("kelp"), YHTagGen.DRIED_KELP);
	public static final IngredientTableItem HOSOMAKI = KELP.with(variant("open_hosomaki").putDefault("kelp", "rice"), YHTagGen.COOKED_RICE);
	public static final IngredientTableItem FUTOMAKI = HOSOMAKI.with(variant("open_futomaki").putDefault("kelp", "rice"), YHTagGen.COOKED_RICE);

	public static final VariantTableItemBase BASE_SUSHI = SUSHI.asBase(YoukaisHomecoming.loc("sushi"));
	public static final VariantTableItemBase BASE_GUNKAN = GUNKAN.asBase(YoukaisHomecoming.loc("gunkan"));
	public static final VariantTableItemBase BASE_HOSOMAKI = HOSOMAKI.asBase(YoukaisHomecoming.loc("hosomaki"));
	public static final VariantTableItemBase BASE_FUTOMAKI = FUTOMAKI.asBase(YoukaisHomecoming.loc("futomaki"));
	public static final VariantTableItemBase BASE_CAL = CAL.asBase(YoukaisHomecoming.loc("california"));

	public static final VariantModelPart SUSHI_TOP = BASE_SUSHI.addPart("top", 1);
	public static final VariantModelPart SUSHI_KELP = BASE_SUSHI.addPart("kelp", 1);
	public static final VariantModelPart SUSHI_CURD = BASE_SUSHI.addPart("curd", 1);
	public static final VariantModelPart SUSHI_SAUCE = BASE_SUSHI.addPart("sauce", 1);
	public static final VariantModelPart GUNKAN_TOP = BASE_GUNKAN.addPart("top", 1);
	public static final VariantModelPart HOSOMAKI_SAUCE = BASE_HOSOMAKI.addPart("sauce", 1);
	public static final VariantModelPart HOSOMAKI_INGREDIENT = BASE_HOSOMAKI.addPart("ingredient", 1);
	public static final VariantModelPart FUTOMAKI_SAUCE = BASE_FUTOMAKI.addPart("sauce", 1);
	public static final VariantModelPart FUTOMAKI_INGREDIENT = BASE_FUTOMAKI.addPart("ingredient", 5);
	public static final VariantModelPart CAL_SAUCE = BASE_CAL.addPart("sauce", 1);
	public static final VariantModelPart CAL_INGREDIENT = BASE_CAL.addPart("ingredient", 5);

	public static final FoodTableItemBase COMPLETE_HOSOMAKI = BASE_HOSOMAKI.addNextStep(null);
	public static final FoodTableItemBase COMPLETE_FUTOMAKI = BASE_FUTOMAKI.addNextStep(null);
	public static final FoodTableItemBase COMPLETE_CALI = BASE_CAL.addNextStep(top("california"));

	public static final VariantModelPart CAL_TOP = COMPLETE_CALI.addPart("top", 3);
	public static final VariantModelPart CAL_COVER = COMPLETE_CALI.addPart("cover", 1);
	public static final VariantModelPart CAL_TOP_SAUCE = COMPLETE_CALI.addPart("sauce", 1);

	@Override
	public Optional<TableItem> find(Level level, ItemStack stack) {
		var ans = super.find(level, stack);
		if (ans.isPresent()) return ans;
		var preset = FoodModelHelper.find(stack);
		if (preset != null) return Optional.of(new FoodTableItem(preset.base(), stack));
		var rec = level.getRecipeManager().getAllRecipesFor(YHBlocks.CUISINE_RT.get());
		for (var e : rec) {
			if (ItemStack.isSameItemSameComponents(e.value().getResult(), stack)) {
				return e.value().recreate();
			}
		}
		return Optional.empty();
	}

	public Either<TableItem, Pair<TableItem, List<ItemStack>>> find(Level level, List<ItemStack> list) {
		TableItem ans = TABLE;
		List<ItemStack> success = new ArrayList<>();
		for (var e : list) {
			var opt = ans.find(level, e);
			if (opt.isEmpty()) return Either.right(Pair.of(ans, success));
			success.add(e);
			ans = opt.get();
		}
		return Either.left(ans);
	}

	public static void init() {
		TableBambooBowls.init();
	}

	public static void prepareData() {
		SUSHI_TOP.addMapping("salmon", CommonTags.FOODS_RAW_SALMON).seareable();
		SUSHI_TOP.addMapping("cod", CommonTags.FOODS_RAW_COD);
		SUSHI_TOP.addMapping("tamagoyaki", YHTagGen.TAMAGOYAKI);
		SUSHI_TOP.addMapping("lamprey", YHTagGen.COOKED_EEL);
		SUSHI_TOP.addMapping("tuna", YHTagGen.RAW_TUNA);
		SUSHI_TOP.addMapping("otoro", YHTagGen.OTORO);
		SUSHI_KELP.addMapping("kelp", Items.DRIED_KELP);
		SUSHI_SAUCE.addMapping("sugar", Items.SUGAR).seareable();
		SUSHI_SAUCE.addMapping("mayonnaise", YHItems.MAYONNAISE.item);

		GUNKAN_TOP.addMapping("roe", YHTagGen.SALMON_ROE);
		GUNKAN_TOP.addMapping("crab_roe", YHTagGen.CRAB_ROE);
		GUNKAN_TOP.addMapping("seagrass", Items.SEAGRASS);
		GUNKAN_TOP.addMapping("nattou", YHTagGen.NATTOU);
		//shirako
		CAL_TOP.addMapping("salmon", CommonTags.FOODS_RAW_SALMON).seareable();
		CAL_TOP.addMapping("cod", CommonTags.FOODS_RAW_COD);
		CAL_TOP.addMapping("tuna", YHTagGen.RAW_TUNA);
		CAL_TOP.addMapping("otoro", YHTagGen.OTORO);
		CAL_COVER.addMapping("roe", YHTagGen.SALMON_ROE);
		CAL_COVER.addMapping("crab_roe", YHTagGen.CRAB_ROE);

		VariantModelPart[] rolls = {HOSOMAKI_INGREDIENT, FUTOMAKI_INGREDIENT, CAL_INGREDIENT};
		VariantModelPart[] sauces = {HOSOMAKI_SAUCE, FUTOMAKI_SAUCE, CAL_SAUCE, CAL_TOP_SAUCE};

		addBulk("soy_sauce", "sauce/soy_sauce", YHTagGen.SOY_SAUCE_BOTTLE, sauces);
		addBulk("mayonnaise", "sauce/mayonnaise", YHTagGen.MAYONNAISE_BOTTLE, sauces);

		addBulk("salmon", "ingredient/salmon", CommonTags.FOODS_RAW_SALMON, rolls);
		addBulk("tuna", "ingredient/tuna", YHTagGen.RAW_TUNA, rolls);
		addBulk("carrot", "ingredient/carrot", Items.CARROT, rolls);
		addBulk("beetroot", "ingredient/beetroot", Items.BEETROOT, rolls);
		addBulk("tamagoyaki", "ingredient/tamagoyaki", YHTagGen.TAMAGOYAKI_SLICE, rolls);
		addBulk("imitation_crab", "ingredient/imitation_crab", YHTagGen.IMITATION_CRAB, rolls);
		addBulk("cucumber", "ingredient/cucumber", YHTagGen.CUCUMBER_SLICE, rolls);
		// kappa
	}

	private static void addBulk(String id, String path, ItemLike item, VariantModelPart... parts) {
		for (var part : parts) {
			part.addMapping(id, item).tex(YoukaisHomecoming.loc("block/table/" + path));
		}
	}

	private static void addBulk(String id, String path, TagKey<Item> item, VariantModelPart... parts) {
		for (var part : parts) {
			part.addMapping(id, item).tex(YoukaisHomecoming.loc("block/table/" + path));
		}
	}

}
