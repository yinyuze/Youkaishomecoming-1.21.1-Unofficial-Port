package dev.xkmc.youkaishomecoming.content.pot.kettle;

import dev.xkmc.l2core.base.tile.BaseTank;
import dev.xkmc.l2modularblock.tile_api.BlockContainer;
import dev.xkmc.l2serial.serialization.marker.SerialClass;
import dev.xkmc.l2serial.serialization.marker.SerialField;
import dev.xkmc.youkaishomecoming.content.block.furniture.LeftClickBlock;
import dev.xkmc.youkaishomecoming.content.pot.base.FluidItemTile;
import dev.xkmc.youkaishomecoming.content.pot.base.TimedRecipeBlockEntity;
import dev.xkmc.youkaishomecoming.content.pot.overlay.InfoTile;
import dev.xkmc.youkaishomecoming.content.pot.overlay.TileTooltip;
import dev.xkmc.youkaishomecoming.init.data.YHLangData;
import dev.xkmc.youkaishomecoming.init.registrate.YHBlocks;
import dev.xkmc.youkaishomecoming.init.registrate.YHItems;
import dev.xkmc.youkaishomecoming.util.DCFluid;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.Container;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.wrapper.InvWrapper;
import org.jetbrains.annotations.Nullable;
import vectorwing.farmersdelight.common.block.entity.HeatableBlockEntity;

import java.util.List;

import static net.minecraft.world.level.block.Block.popResource;

@SerialClass
public class KettleBlockEntity extends TimedRecipeBlockEntity<KettleRecipe, KettleContainer>
		implements InfoTile, HeatableBlockEntity, LeftClickBlock, FluidItemTile, BlockContainer {

	@SerialField
	private final KettleContainer items = new KettleContainer(4).setMax(1).add(this);

	@SerialField
	public final BaseTank fluids = new BaseTank(1, 1000).add(this);

	@SerialField
	private int heat = 0;

	private final IItemHandler itemHandler = new InvWrapper(items);

	public KettleBlockEntity(BlockEntityType<KettleBlockEntity> type, BlockPos pos, BlockState state) {
		super(type, pos, state);
	}

	@Override
	public RecipeType<KettleRecipe> getRecipeType() {
		return YHBlocks.KETTLE_RT.get();
	}

	@Override
	protected boolean isEmpty() {
		return items.isEmpty();
	}

	@Override
	public BaseTank getFluidHandler() {
		return fluids;
	}

	@Override
	public SimpleContainer getItemHandler() {
		return items;
	}

	@Override
	protected boolean shouldStopProcessing(Level level) {
		if (heat < 1000) return true;
		var stack = fluids.getFluidInTank(0);
		if (stack.getAmount() < 1000) return true;
		return !stack.getFluid().is(FluidTags.WATER);
	}

	@Override
	protected KettleContainer createContainer() {
		return items;
	}

	@Override
	public List<Container> getContainers() {
		return List.of(items);
	}

	@Override
	protected void finishRecipe(Level level, KettleRecipe recipe) {
		items.clear();
		fluids.set(1, 0, recipe.result.copy());
		heat = 0;
	}

	@Override
	public void tick() {
		if (level == null) return;
		var fluid = fluids.getFluidInTank(0);
		if (fluid.getFluid().is(FluidTags.WATER)) {
			if (heat >= fluid.getAmount())
				heat = fluid.getAmount();
			else {
				if (isHeated(level, getBlockPos()))
					heat++;
			}
		} else heat = 0;
		super.tick();
	}

	public void dumpInventory() {
		if (level == null) return;
		Containers.dropContents(level, this.getBlockPos().above(), items);
		notifyTile();
	}

	public void readFromStack(ItemStack stack) {
		var cont = stack.get(YHItems.DC_ITEMS);
		if (cont != null) {
			for (int i = 0; i < cont.getSlots(); i++) {
				items.addItem(cont.getStackInSlot(i));
			}
		}
		var fluid = stack.get(YHItems.DC_FLUID);
		if (fluid != null)
			fluids.set(1, 0, fluid.stack().copy());
		heat = stack.getOrDefault(YHItems.DC_HEAT, 0);
	}

	@Override
	public boolean leftClick(BlockState state, Level level, BlockPos pos, Player player) {
		if (level.isClientSide) return true;
		ItemStack stack = state.getBlock().asItem().getDefaultInstance();
		var ans = ItemContainerContents.fromItems(items.getAsList());
		items.clear();
		stack.set(YHItems.DC_ITEMS, ans);
		stack.set(YHItems.DC_FLUID, new DCFluid(fluids.getFluidInTank(0).copy()));
		stack.set(YHItems.DC_HEAT, heat);
		level.removeBlock(pos, false);
		if (player.getMainHandItem().isEmpty()) {
			player.setItemInHand(InteractionHand.MAIN_HAND, stack);
		} else {
			popResource(level, pos, stack);
		}
		return true;
	}

	@Override
	public TileTooltip getImage(boolean shift, BlockHitResult hit) {
		return new TileTooltip(items.getAsList(), fluids.getAsList(), 3, 2);
	}

	@Override
	public List<Component> lines(boolean shift, BlockHitResult hit) {
		var fluid = fluids.getFluidInTank(0);
		if (!fluid.getFluid().is(FluidTags.WATER)) return List.of();
		var prog = inProgress();
		if (prog > 0) return List.of(YHLangData.BREWING_PROGRESS.get(Math.round(prog * 100) + "%"));
		return List.of(YHLangData.HEAT_PROGRESS.get(heat / 10 + "%"));
	}

	public void heatUp(int val) {
		var fluid = fluids.getFluidInTank(0);
		if (!fluid.getFluid().is(FluidTags.WATER)) {
			heat = 0;
			return;
		}
		heat = Math.min(fluid.getAmount(), heat + val);
	}

	public void prepareforHotWater(int space) {
		var fluid = fluids.getFluidInTank(0);
		if (!fluid.getFluid().is(FluidTags.WATER)) return;
		if (heat < fluid.getAmount() && fluid.getAmount() + space > 1000) {
			fluid.setAmount(Math.max(heat, 1000 - space));
		}
	}

	public @Nullable IItemHandler getItemCap(@Nullable Direction dir) {
		return itemHandler;
	}

}
