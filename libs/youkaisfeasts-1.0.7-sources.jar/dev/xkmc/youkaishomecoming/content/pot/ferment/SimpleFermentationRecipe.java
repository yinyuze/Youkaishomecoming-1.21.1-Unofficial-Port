package dev.xkmc.youkaishomecoming.content.pot.ferment;

import dev.xkmc.l2serial.serialization.marker.SerialClass;
import dev.xkmc.l2serial.serialization.marker.SerialField;
import dev.xkmc.youkaishomecoming.init.registrate.YHBlocks;
import net.minecraft.core.HolderLookup;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.Fluids;
import net.neoforged.neoforge.fluids.FluidStack;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@SerialClass
public class SimpleFermentationRecipe extends FermentationRecipe<SimpleFermentationRecipe> {

	@SerialField
	public ArrayList<Ingredient> ingredients = new ArrayList<>();

	@SerialField
	public ArrayList<ItemStack> results = new ArrayList<>();

	@SerialField
	public FluidStack outputFluid = FluidStack.EMPTY;

	@SerialField
	public FluidStack inputFluid = FluidStack.EMPTY;

	@SerialField
	public int time;

	@SerialField
	public ItemStack defaultContainer = ItemStack.EMPTY, defaultBottle = ItemStack.EMPTY;

	public SimpleFermentationRecipe() {
		super(YHBlocks.FERMENT_RS.get());
	}

	@Override
	public boolean matches(FermentationDummyContainer cont, Level level) {
		FluidStack fluid = cont.fluids().getFluidInTank(0);
		if (!inputFluid.isEmpty()) {
			if (fluid.getAmount() < inputFluid.getAmount())
				return false;
			if (inputFluid.getFluid() == Fluids.WATER) {
				if (!fluid.getFluid().is(FluidTags.WATER)) {
					return false;
				}
			} else if (inputFluid.getFluid().getFluidType() != fluid.getFluid().getFluidType()) {
				return false;
			}
		} else {
			if (!fluid.isEmpty())
				return false;
		}
		if (isSimple()) {
			for (var e : cont.items().getAsList()) {
				if (!e.isEmpty() && !ingredients.get(0).test(e)) {
					return false;
				}
			}
			return true;
		}
		Set<ItemStack> available = new LinkedHashSet<>();
		for (var e : cont.items().getAsList()) {
			if (e.isEmpty()) continue;
			available.add(e);
		}
		for (var ing : ingredients) {
			ItemStack match = null;
			for (var e : available) {
				if (ing.test(e)) {
					match = e;
					break;
				}
			}
			if (match == null) {
				return false;
			}
			available.remove(match);
		}
		return available.isEmpty();
	}

	@Override
	public ItemStack assemble(FermentationDummyContainer cont, HolderLookup.Provider access) {
		List<ItemStack> remain = new ArrayList<>();
		for (var e : cont.items().getAsList()) {
			ItemStack rem = e.getCraftingRemainingItem();
			if (!rem.isEmpty()) {
				remain.add(rem);
			}
		}
		if (isSimple()) {
			if (!results.isEmpty()) {
				for (var e : cont.items().getAsList()) {
					if (!e.isEmpty())
						remain.add(results.get(0).copy());
				}
			}
			cont.items().clearContent();
		} else {
			cont.items().clearContent();
			for (var e : results) {
				cont.items().addItem(e.copy());
			}
		}
		for (var e : remain) {
			cont.items().addItem(e);
		}
		int amount = cont.fluids().getFluidInTank(0).getAmount();
		cont.fluids().clear();
		if (!outputFluid.isEmpty()) {
			FluidStack ans = outputFluid.copy();
			ans.setAmount(amount);
			cont.fluids().set(0, 0, ans);
		}
		return ItemStack.EMPTY;
	}

	@Override
	public int getProcessTime() {
		return time;
	}

	public boolean isSimple() {
		return ingredients.size() == 1 &&
				inputFluid.isEmpty() && outputFluid.isEmpty() &&
				defaultBottle.isEmpty() && defaultBottle.isEmpty();
	}
}
