package dev.xkmc.youkaishomecoming.content.block.plant.grape;

import com.mojang.serialization.MapCodec;
import dev.xkmc.l2harvester.api.HarvestResult;
import dev.xkmc.l2harvester.api.HarvestableBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Ravager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.neoforged.neoforge.common.CommonHooks;
import net.neoforged.neoforge.event.EventHooks;
import org.jetbrains.annotations.Nullable;
import vectorwing.farmersdelight.common.registry.ModSounds;

import java.util.List;

import static dev.xkmc.youkaishomecoming.content.block.plant.rope.RopeLoggedCropBlock.getRopeBlock;

@SuppressWarnings("deprecation")
public abstract class BaseCropVineBlock extends BushBlock implements HarvestableBlock {

	@Override
	protected MapCodec<? extends BushBlock> codec() {
		return null;
	}

	public static final BooleanProperty TOP = BooleanProperty.create("top");

	public BaseCropVineBlock(BlockBehaviour.Properties prop) {
		super(prop);
		this.registerDefaultState(this.stateDefinition.any()
				.setValue(this.getAgeProperty(), 0)
				.setValue(TOP, false)
		);
	}

	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(getAgeProperty(), TOP);
	}

	protected abstract IntegerProperty getAgeProperty();

	public abstract int getMaxAge();

	protected abstract int getBaseAge();

	protected abstract VineTrunkBlock getTrunk();

	protected abstract ItemLike getFruit();

	@Nullable
	protected abstract BlockPos getTrunk(BlockState state, BlockGetter level, BlockPos pos);

	public abstract ItemStack getCloneItemStack(LevelReader level, BlockPos pos, BlockState state);

	@Override
	public InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
		if (state.getValue(getAgeProperty()) == getMaxAge()) {
			if (!level.isClientSide()) {
				pickup(state, level, pos, player);
			}
			level.playSound(player, pos, ModSounds.ITEM_TOMATO_PICK_FROM_BUSH.get(), SoundSource.BLOCKS, 1.0F, 0.8F + level.random.nextFloat() * 0.4F);
			return InteractionResult.SUCCESS;
		}
		return InteractionResult.PASS;
	}

	protected void pickup(BlockState state, Level level, BlockPos pos, Player player) {
		int quantity = 1 + level.random.nextInt(2);
		popResource(level, pos, new ItemStack(getFruit(), quantity));
		level.setBlock(pos, state.setValue(getAgeProperty(), getBaseAge()), 2);
	}

	@Override
	public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
		return getTrunk(state, level, pos) != null;
	}

	protected float getGrowthSpeed(BlockState state, BlockGetter level, BlockPos pos) {
		var trunk = getTrunk(state, level, pos);
		if (trunk == null)
			return 0;
		return getTrunk().getGrowthSpeed(level, pos);
	}

	protected boolean mayGrow(BlockState state, LevelReader level, BlockPos pos) {
		return level.getRawBrightness(pos, 0) >= 9;
	}

	protected boolean attemptGrowth(BlockState state, LevelReader level, BlockPos pos, @Nullable RandomSource random, boolean simulate, boolean natural, float speed) {
		int age = state.getValue(getAgeProperty());
		if (age < getMaxAge()) {
			if (simulate) return true;
			assert random != null;
			Level setter = (Level) level;
			if (!natural) {
				doGrowth(state, setter, pos, random);
				return true;
			} else if (CommonHooks.canCropGrow(setter, pos, state, random.nextFloat() < speed)) {
				setter.setBlock(pos, state.setValue(getAgeProperty(), age + 1), 2);
				CommonHooks.fireCropGrowPost(setter, pos, state);
				return true;
			}
		}
		return false;
	}

	protected void doGrowth(BlockState state, Level level, BlockPos pos, RandomSource random) {
		int age = state.getValue(getAgeProperty());
		if (age < getMaxAge()) {
			level.setBlock(pos, state.setValue(getAgeProperty(), age + 1), 2);
		}
	}

	public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource rand) {
		if (!level.isAreaLoaded(pos, 1)) return;
		float f = getGrowthSpeed(state, level, pos) * 0.02f;
		if (!mayGrow(state, level, pos)) return;
		attemptGrowth(state, level, pos, rand, false, true, f);
	}

	public void entityInside(BlockState state, Level level, BlockPos pos, Entity e) {
		if (e instanceof Ravager && EventHooks.canEntityGrief(level, e)) {
			level.destroyBlock(pos, true, e);
		}
		super.entityInside(state, level, pos, e);
	}

	@Override
	public @Nullable HarvestResult getHarvestResult(Level level, BlockState state, BlockPos pos) {
		if (state.getValue(getAgeProperty()) < getMaxAge()) return null;
		int quantity = 1 + level.random.nextInt(2);
		return new HarvestResult(state.setValue(getAgeProperty(), getBaseAge()),
				List.of(new ItemStack(getFruit(), quantity)));
	}

	public void playerDestroy(Level level, Player player, BlockPos pos, BlockState state, @Nullable BlockEntity be, ItemStack stack) {
		doPlayerDestroy(level, player, pos, state, be, stack);
		destroyAndPlaceRope(level, pos);
	}

	public void doPlayerDestroy(Level level, Player player, BlockPos pos, BlockState state, @Nullable BlockEntity be, ItemStack stack) {
		super.playerDestroy(level, player, pos, state, be, stack);
	}

	public BlockState updateShape(BlockState state, Direction facing, BlockState fstate, LevelAccessor level, BlockPos cpos, BlockPos fpos) {
		if (!state.canSurvive(level, cpos)) {
			level.scheduleTick(cpos, this, 1);
		}
		return state;
	}

	public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
		level.destroyBlock(pos, true);
		destroyAndPlaceRope(level, pos);

	}

	public static void destroyAndPlaceRope(Level level, BlockPos pos) {
		level.setBlockAndUpdate(pos, getRopeBlock());
	}

}
