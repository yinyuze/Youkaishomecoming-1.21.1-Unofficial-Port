package dev.xkmc.youkaishomecoming.compat.jei;

import dev.xkmc.l2core.compat.jei.BaseRecipeCategory;
import dev.xkmc.youkaishomecoming.content.item.fluid.BottledDrinkSet;
import dev.xkmc.youkaishomecoming.content.item.fluid.IYHFluidBottled;
import dev.xkmc.youkaishomecoming.content.item.fluid.IYHFluidItem;
import dev.xkmc.youkaishomecoming.content.item.fluid.YHFluidHandler;
import dev.xkmc.youkaishomecoming.content.pot.ferment.SimpleFermentationRecipe;
import dev.xkmc.youkaishomecoming.init.YoukaisHomecoming;
import dev.xkmc.youkaishomecoming.init.data.YHLangData;
import dev.xkmc.youkaishomecoming.init.registrate.YHBlocks;
import dev.xkmc.youkaishomecoming.init.registrate.YHItems;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.neoforge.NeoForgeTypes;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class FermentRecipeCategory extends BaseRecipeCategory<SimpleFermentationRecipe, FermentRecipeCategory> {
	protected static final ResourceLocation BG = YoukaisHomecoming.loc("textures/gui/ferment.png");

	public FermentRecipeCategory() {
		super(YoukaisHomecoming.loc("ferment"), SimpleFermentationRecipe.class);
	}

	public FermentRecipeCategory init(IGuiHelper guiHelper) {
		this.background = guiHelper.createDrawable(BG, 0, 0, 144, 54);
		this.icon = guiHelper.createDrawableIngredient(VanillaTypes.ITEM_STACK, YHBlocks.FERMENT.asStack());
		return this;
	}

	public Component getTitle() {
		return YHLangData.JEI_FERMENT.get();
	}

	public void setRecipe(IRecipeLayoutBuilder builder, SimpleFermentationRecipe recipe, IFocusGroup focuses) {
		if (recipe.isSimple()) {
			var in = recipe.ingredients.get(0).getItems();
			var out = recipe.results.isEmpty() ? ItemStack.EMPTY : recipe.results.get(0);
			int n = in.length;
			for (int i = 0; i < 8; i++) {
				int y = i / 3 * 18 + 1;
				int x = i % 3 * 18 + 1;
				var inList = new ItemStack[n * 8];
				var outList = new ItemStack[n * 8];
				for (int j = 0; j < 8; j++) {
					for (int k = 0; k < n; k++) {
						if (j >= i) {
							inList[j * n + k] = in[k];
							outList[j * n + k] = out;
						} else {
							inList[j * n + k] = ItemStack.EMPTY;
							outList[j * n + k] = ItemStack.EMPTY;
						}
					}
				}
				builder.addSlot(RecipeIngredientRole.INPUT, x, y).addItemStacks(List.of(inList));
				builder.addSlot(RecipeIngredientRole.OUTPUT, x + 90, y).addItemStacks(List.of(outList));
			}
			return;
		}
		int n = 0;
		for (var stack : recipe.ingredients) {
			if (stack.isEmpty()) continue;
			int y = n / 3 * 18 + 1;
			int x = n % 3 * 18 + 1;
			builder.addSlot(RecipeIngredientRole.INPUT, x, y).addIngredients(stack);
			n++;
		}
		if (!recipe.inputFluid.isEmpty()) {
			int y = n / 3 * 18 + 1;
			int x = n % 3 * 18 + 1;
			if (YHFluidHandler.of(recipe.inputFluid) instanceof IYHFluidItem f) {
				builder.addSlot(RecipeIngredientRole.INPUT, x, y).addItemStack(f.toStack(recipe.inputFluid));
			} else {
				builder.addSlot(RecipeIngredientRole.INPUT, x, y).addIngredients(NeoForgeTypes.FLUID_STACK, List.of(recipe.inputFluid));
			}
		}
		n = 0;
		for (var stack : recipe.results) {
			if (stack.isEmpty()) continue;
			int y = n / 3 * 18 + 1;
			int x = n % 3 * 18 + 91;
			builder.addSlot(RecipeIngredientRole.OUTPUT, x, y).addItemStack(stack);
			n++;
		}
		if (!recipe.outputFluid.isEmpty()) {
			int y = n / 3 * 18 + 1;
			int x = n % 3 * 18 + 91;
			if (YHFluidHandler.of(recipe.outputFluid) instanceof IYHFluidBottled sake) {
				var list = new ArrayList<ItemStack>();
				var conts = new ArrayList<ItemStack>();
				list.add(sake.toStack(recipe.outputFluid));
				conts.add(new ItemStack(sake.getContainer(), sake.count()));
				if (sake.bottleSet() instanceof BottledDrinkSet set) {
					list.add(set.bottle.asStack(1));
					conts.add(YHItems.SAKE_BOTTLE.asStack(1));
				}
				builder.addSlot(RecipeIngredientRole.OUTPUT, x, y).addItemStacks(list);
				builder.addSlot(RecipeIngredientRole.INPUT, 64, 1).addItemStacks(conts);
			} else {
				if (!recipe.defaultContainer.isEmpty() && !recipe.defaultBottle.isEmpty()) {
					builder.addSlot(RecipeIngredientRole.OUTPUT, x, y).addItemStack(recipe.defaultBottle);
					builder.addSlot(RecipeIngredientRole.INPUT, 64, 1).addItemStack(recipe.defaultContainer);
				} else {
					builder.addSlot(RecipeIngredientRole.OUTPUT, x, y).addIngredients(NeoForgeTypes.FLUID_STACK, List.of(recipe.outputFluid));
				}
			}
		}
	}
}
