package dev.xkmc.danmakuapi.init;

import dev.xkmc.danmakuapi.content.virtual.ClientDanmakuCache;
import dev.xkmc.fastprojectileapi.render.ProjectileRenderHelper;

public final class DanmakuAPIClient {

	private DanmakuAPIClient() {
	}

	public static void initClient() {
		ProjectileRenderHelper.LIST.add(ClientDanmakuCache::get);
	}
}
